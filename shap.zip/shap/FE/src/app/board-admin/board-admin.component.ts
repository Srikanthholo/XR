import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '../shared/api.service';
import { AuthService } from '../_services/auth.service';
import { TokenStorageService } from '../_services/token-storage.service';
import { UserService } from '../_services/user.service';
import { NgAnalyzeModulesHost, ThisReceiver } from '@angular/compiler';
import { FormBuilder, FormGroup } from '@angular/forms';

import { CalendarOptions, getEventClassNames } from '@fullcalendar/angular';
import { EVENT } from 'src/app/models/event.model';
import { EventService } from 'src/app/_services/event.service';
import { HttpClient } from '@angular/common/http';
import { TeacherService } from '../_services/teacher.service';
import { StudentService } from '../_services/student.service';
import { SubjectService } from '../_services/subject.service';
import { SectionService } from '../_services/sections.service';
import { ContentService } from '../_services/content.service';
import { TresultService } from '../_services/tresult.service';


@Component({
  selector: 'app-board-admin',
  templateUrl: './board-admin.component.html',
  styleUrls: ['./board-admin.component.css']
})
export class BoardAdminComponent implements OnInit {
 
 
  Events: EVENT[] = [];
  calendarOptions: CalendarOptions = {
    headerToolbar: {
      left: 'prev,next today',
      center: 'title',
      right: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek'
    },
    initialView: 'dayGridMonth',
    weekends: true,
    editable: true,
    selectable: true,
    selectMirror: true,
    dayMaxEvents: true
    
  };

 
  submitted = false;

 
  currenteventdata: any;
  liveeventdata:any;

  event: EVENT = {
    
    title: '',
    description:'',
    date:'',
    studentid:'',
    customerid:'',
    published:false,
    createdAt:'',
  
  };
  el: any;
  noevents!: boolean;
  studentData: any;
  teacherData: any;
  subjectData: any;
  sectionData: any;
  schoolteachers: any;
  schoolstudents: any;
  schoolsubjects: any;
  schoolsections: any;
  currentexamresult: any;
 
 
  constructor(private userService: UserService, 
       private eventservice :EventService,
       private httpClient: HttpClient,
       private teacherservice: TeacherService,
       private studnetservice: StudentService,
       private subjectservice :ContentService,
       private sectionservice : SectionService,
       private tresultservice :TresultService,
    private authService: AuthService, private tokenStorage: TokenStorageService, public router: Router,  public  api: ApiService ) { }
    onDateClick(res: any) {
      //alert('Clicked on date : ' + res.dateStr);
      const date = res.dateStr;
      //alert(date);
      this.getEvent(date);
   
    }
 
  ngOnInit(): void {
 
    this.retrieveEvents();
    this.retrieveTeachers();
    this.retrieveStudents();
    this.retrieveSubjects();
    this.retrieveSections();
    this.retriveReuslts();

    setTimeout(() => {
      return this.httpClient
        .get('http://localhost:8080/api/events')
        .subscribe((res: any) => {
          this.Events.push(res);
          console.log(this.Events);
        });
    }, 2200);
    setTimeout(() => {
      this.calendarOptions = {
        initialView: 'dayGridMonth',
        dateClick: this.onDateClick.bind(this),
       // events: this.Events,
        events: this.currenteventdata,
      };
    }, 2500);   
   


  }


    
  retriveReuslts(){

    this.tresultservice.getAll()
    .subscribe({
      next: (data) => {
       this.currentexamresult= data;
        //this.currentexamresult = data.sort((one:any, two :any) => (Number(one.fullname) >= Number(two.fullname) ? -1 : 1));
      //this.setrank(this.currentexamresult);

       
        console.log(this.currentexamresult);

     
    
      },
      error: (e) => console.error(e)
    });
  }



  retrieveEvents(): void {
    
    this.eventservice.getAll()
      .subscribe({
        next: (data) => {

          this.currenteventdata = data;
         
          console.log(data);
        },
        error: (e) => console.error(e)
      });
  }
 
  getEvent ( date : any): void {
    this.eventservice.findBydate(date)
      .subscribe({
        next: (res) => {
          console.log(res);
          this.liveeventdata = res;
          if(this.liveeventdata.length == 0){
            this.noevents = true;

          }
          else{

            this.noevents = false;
          }


        },
        error: (e) =>{
  
          console.error(e);
          alert(e.message);
        }
         
      });
  }


  retrieveTeachers(){

    this.teacherservice.getAll()
    .subscribe({
      next: (data) => {
         this.teacherData = data;
        this.schoolteachers = this.teacherData.length;
  
      },
      error: (e) => console.error(e)
    });

  }

  retrieveStudents(){

    this.studnetservice.getAll()
    .subscribe({
      next: (data) => {
         this.studentData = data;
        this.schoolstudents = this.studentData.length;
  
      },
      error: (e) => console.error(e)
    });

  }
  retrieveSubjects(){

    this.subjectservice.getAll()
    .subscribe({
      next: (data) => {
         this.subjectData = data;
        this.schoolsubjects = this.subjectData.length;
  
      },
      error: (e) => console.error(e)
    });

  }

  retrieveSections(){

    this.sectionservice.getAll()
    .subscribe({
      next: (data) => {
         this.sectionData = data;
        this.schoolsections = this.sectionData.length;
  
      },
      error: (e) => console.error(e)
    });

  }


  
}
