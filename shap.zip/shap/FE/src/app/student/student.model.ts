export class StudentModel{

    id: number= 0;
    name: string='';
    email: string='';
    mobile: string='';
    fees: string='';
    location:string='';
    photourl:string='';
}


