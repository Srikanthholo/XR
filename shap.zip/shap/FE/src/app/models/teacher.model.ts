export class Teacher{

    _id: string='';
    username: string='';
    email: string='';
    password: string='';
    admissionno: string='';
    roles: any;
    fullname:  String='';
    mobile: String='';
    address: String='';
    standard: String='';
    section: String='';
    subject: String='';
    mysections: any;
    profile: String='';
    photourl: String='';

 
}


