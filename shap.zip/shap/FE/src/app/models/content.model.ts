export class CONTENT {
    id?: any;
    subject?: string;
    description?: string;
 
    
  }